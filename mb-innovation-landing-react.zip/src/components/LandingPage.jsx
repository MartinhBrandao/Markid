
import React from "react";
import { Button } from "@/components/ui/button";

export default function LandingPage() {
  return (
    <div className="bg-gray-950 text-white min-h-screen font-sans">
      <header className="text-center py-16 px-4">
        <h1 className="text-4xl md:text-5xl font-bold mb-4">
          Transformamos investimentos em faturamento real.
        </h1>
        <p className="text-lg md:text-xl text-gray-300 max-w-2xl mx-auto">
          A MB Innovation é especializada em campanhas de tráfego pago que geram resultados concretos para o teu negócio.
        </p>
        <div className="mt-6">
          <a href="https://wa.me/244921871161" target="_blank" rel="noopener noreferrer">
            <Button className="bg-green-500 text-white px-6 py-3 text-lg rounded-2xl shadow-md">
              Falar agora no WhatsApp
            </Button>
          </a>
        </div>
      </header>

      <section className="px-6 py-12 bg-gray-900 text-center">
        <h2 className="text-3xl font-bold mb-6">O que fazemos</h2>
        <p className="text-gray-300 max-w-3xl mx-auto mb-8">
          Trabalhamos com anúncios nas maiores plataformas (Facebook, Instagram, Google, TikTok) para atrair, converter e reter clientes para a tua empresa.
        </p>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
          <div className="bg-gray-800 p-6 rounded-2xl shadow">
            ✅ Estratégia personalizada
          </div>
          <div className="bg-gray-800 p-6 rounded-2xl shadow">
            ✅ Otimização diária
          </div>
          <div className="bg-gray-800 p-6 rounded-2xl shadow">
            ✅ Análises e relatórios
          </div>
          <div className="bg-gray-800 p-6 rounded-2xl shadow">
            ✅ Acompanhamento profissional
          </div>
        </div>
      </section>

      <section className="px-6 py-16 bg-gray-950 text-center">
        <h2 className="text-3xl font-bold mb-8">Planos para todos os estágios</h2>
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {[
            {
              name: "Start",
              price: "45.000 Kz",
              desc: "1 campanha, 1 canal, relatório mensal",
              action: "Quero este plano",
            },
            {
              name: "Performance",
              price: "85.000 Kz",
              desc: "Até 3 campanhas, 2 canais, relatórios semanais",
              action: "Quero este plano",
            },
            {
              name: "Escala",
              price: "120.000+ Kz",
              desc: "Múltiplas campanhas, 3 canais, consultoria incluída",
              action: "Agendar conversa",
            },
          ].map((plan) => (
            <div key={plan.name} className="bg-gray-900 p-6 rounded-2xl shadow-lg">
              <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
              <p className="text-green-400 text-xl font-semibold mb-4">{plan.price}</p>
              <p className="text-gray-300 mb-6">{plan.desc}</p>
              <Button className="bg-green-500 text-white px-4 py-2 rounded-xl">
                {plan.action}
              </Button>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-gray-900 px-6 py-16 text-center">
        <h2 className="text-3xl font-bold mb-6">Por que escolher a MB Innovation?</h2>
        <ul className="text-gray-300 space-y-3 max-w-2xl mx-auto">
          <li>✅ Especialistas 100% focados em tráfego pago</li>
          <li>✅ Atendimento direto com especialista</li>
          <li>✅ Testes e otimização contínua</li>
          <li>✅ Relatórios transparentes com foco em vendas</li>
        </ul>
      </section>

      <section className="bg-gray-950 px-6 py-16 text-center">
        <h2 className="text-3xl font-bold mb-8">Resultados de campanhas</h2>
        <div className="flex justify-center">
          <img
            src="https://via.placeholder.com/600x350.png?text=Simulacao+de+Resultados+de+Campanha"
            alt="Resultados de Campanha"
            className="rounded-xl shadow-lg"
          />
        </div>
      </section>

      <footer className="bg-gray-950 py-12 text-center border-t border-gray-800">
        <h2 className="text-2xl font-bold mb-4">Pronto para atrair mais clientes?</h2>
        <a href="https://wa.me/244921871161" target="_blank" rel="noopener noreferrer">
          <Button className="bg-green-500 text-white px-6 py-3 text-lg rounded-2xl shadow-md">
            Falar agora no WhatsApp
          </Button>
        </a>
      </footer>
    </div>
  );
}
